﻿Public Class Usuario
    Public Property nombre As String
    Public Property apellido As String
    Public Property password As String
    Public Property login As String
    Public Property mail As String
    Public Property estado As Integer
    Public Property idUsuario As Integer
    Public Property cargo As String
    Public Property legajo As Integer
    Public Property telefono As Integer
    Public Property documento As Integer

End Class
